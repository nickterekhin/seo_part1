#include "search_server.h"
#include "iterator_range.h"
#include "profile.h"
#include "stat_profile.h"
#include "parse.h"
#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <future>
#include <map>

deque<string> SplitIntoWords(const string &line) {
    istringstream words_input(line);
    return {istream_iterator<string>(words_input), istream_iterator<string>()};
}
deque<string_view> SplitIntoWordsEx(string_view str)
{
    deque<string_view> result;
    while (true)
    {
        size_t space = str.find(' ');

        auto word = Strip(str.substr(0, space));

        if (!word.empty())
            result.push_back(word);

        if (space == str.npos)
        {
            break;
        }
        else
        {
            str.remove_prefix(space + 1);
        }
    }

    return result;
}

SearchServer::SearchServer(istream& document_input) {
     UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {

       InvertedIndex new_index;
    for (string current_document; getline(document_input, current_document); ) {
        new_index.Add(move(current_document));
    }

    index = move(new_index);
}
void SearchServer::AddQueriesStream(istream &query_input, ostream &search_results_output) {

    Profiler profiler;

    vector<set<DocItem>::iterator> _existing_docs_items(50000);
    set<DocItem> _docsItems;

    for(string current_query; getline(query_input, current_query); )
    {
        _docsItems.clear();
        fill(_existing_docs_items.begin(),_existing_docs_items.end(),_docsItems.end());
        deque<string> words;

        {
            STAT_DURATION(profiler, "SplitIntoWords");
            words = SplitIntoWords(current_query);
        }

        for (const auto &word : words) {
            STAT_DURATION(profiler, "Lookup");
            deque<DocItem> items;
            {
                items = index.Lookup(word);
            }
            for (const auto &item : items) {

                if(_existing_docs_items[item._id]!=_docsItems.end())
                {
                        auto node = _docsItems.extract(_existing_docs_items[item._id]);
                        node.value()._hits+=item._hits;
                        auto it = _docsItems.insert(move(node.value()));
                        _existing_docs_items[item._id]= it.first;
                }else
                {
                    auto it = _docsItems.insert(item);
                    _existing_docs_items[item._id] = it.first;
                }
            }
        }

        search_results_output << current_query << ':';

        for (auto &[_id,_hits] : HeadEx(_docsItems,5)) {
            STAT_DURATION(profiler, "MakeOutput");
            search_results_output << " {"
                                  << "docid: " << _id << ", "
                                  << "hitcount: " << _hits << '}';
        }

        search_results_output << endl;

    }
}

/*void SearchServer::AddQueriesStream(istream &query_input, ostream &search_results_output) {

    vector<pair<size_t, size_t*>> search_results(50000);
    Profiler profiler;
    for(string current_query; getline(query_input, current_query); )
    {
       vector<size_t> docid_count(50000);
        search_results.clear();
        deque<string> words;

        {
            STAT_DURATION(profiler, "SplitIntoWords");
            words = SplitIntoWords(current_query);
        }

        for (const auto &word : words) {
            STAT_DURATION(profiler, "Lookup");
            deque<DocItem> items;
            {
                items = index.Lookup(word);
            }
            for (const auto &item : items) {


                if(docid_count[item._id]==0)
                {
                    search_results.emplace_back(item._id,&docid_count[item._id]);
                }
                docid_count[item._id]+=item._hits;
            }
        }

                auto middle = search_results.size() > 5 ? begin(search_results) + 5 : end(search_results);

        {
            STAT_DURATION(profiler, "Sort");
            partial_sort(search_results.begin(), middle, search_results.end(),
                         [](const pair<size_t, size_t *> &lhs, const pair<size_t, size_t *> &rhs) {

                             int64_t lhs_docid = lhs.first;
                             auto lhs_hit_count = *lhs.second;
                             int64_t rhs_docid = rhs.first;
                             auto rhs_hit_count = *rhs.second;
                             return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
                         });
        }
        search_results_output << current_query << ':';

        for (auto &[_id,_hits] : Head(search_results,5)) {
            STAT_DURATION(profiler, "MakeOutput");
            search_results_output << " {"
                                  << "docid: " << _id << ", "
                                  << "hitcount: " << *_hits << '}';
        }

        search_results_output << endl;
    }

}*/

void InvertedIndex::Add(const string& document) {

    const size_t docid = docs_id++;

    map<string_view, size_t*> words;
    for (auto& word : SplitIntoWords(document)) {
        auto it = words.find(word);
        if (it == words.end())
        {
            auto& point = index[word];
            point.push_back({docid, 1});
            words[word] = &point[point.size() - 1]._hits;
        }
        else
        {
            *(it->second) = *(it->second) + 1;
        }
    }
}

deque<DocItem> InvertedIndex::Lookup(const string &word) const {

    if (auto it = index.find(word); it != index.end()) {
        return it->second;
    } else {
        return {};
    }
}
